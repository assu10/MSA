package org.rvslab.chap02.boothateoas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BoothateoasApplication {

	public static void main(String[] args) {
		SpringApplication.run(BoothateoasApplication.class, args);
	}
}
